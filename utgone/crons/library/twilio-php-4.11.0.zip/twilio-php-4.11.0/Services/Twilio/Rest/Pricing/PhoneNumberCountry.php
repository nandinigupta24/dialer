<?php
class Services_Twilio_Rest_Pricing_PhoneNumberCountry
    extends Services_Twilio_PricingInstanceResource {
}