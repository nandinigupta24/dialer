<?php

class Services_Twilio_Rest_Trunking_PhoneNumber extends Services_Twilio_TrunkingInstanceResource {

}
